﻿namespace MarketManagmentSystem
{
    internal class comboBoxSelectRole
    {
    }
}