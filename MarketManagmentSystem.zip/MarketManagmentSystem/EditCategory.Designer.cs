﻿namespace MarketManagmentSystem
{
    partial class EditCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtBoxCatEditDescription = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxCatEditName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBoxCatEditcancel = new System.Windows.Forms.Button();
            this.btnBoxCatEditOk = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxCatEditID = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.roundButton2 = new MarketManagmentSystem.RoundButton();
            this.roundButton1 = new MarketManagmentSystem.RoundButton();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Gill Sans MT", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(13, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 23);
            this.label3.TabIndex = 83;
            this.label3.Text = "Your Label";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Location = new System.Drawing.Point(176, 282);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(231, 4);
            this.panel1.TabIndex = 82;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel3.Location = new System.Drawing.Point(178, 176);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(231, 4);
            this.panel3.TabIndex = 81;
            // 
            // txtBoxCatEditDescription
            // 
            this.txtBoxCatEditDescription.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txtBoxCatEditDescription.Location = new System.Drawing.Point(177, 212);
            this.txtBoxCatEditDescription.Name = "txtBoxCatEditDescription";
            this.txtBoxCatEditDescription.Size = new System.Drawing.Size(231, 73);
            this.txtBoxCatEditDescription.TabIndex = 80;
            this.txtBoxCatEditDescription.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(12, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 30);
            this.label2.TabIndex = 79;
            this.label2.Text = "Description";
            // 
            // txtBoxCatEditName
            // 
            this.txtBoxCatEditName.BackColor = System.Drawing.Color.White;
            this.txtBoxCatEditName.Font = new System.Drawing.Font("Gill Sans MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCatEditName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txtBoxCatEditName.Location = new System.Drawing.Point(177, 150);
            this.txtBoxCatEditName.Name = "txtBoxCatEditName";
            this.txtBoxCatEditName.Size = new System.Drawing.Size(232, 30);
            this.txtBoxCatEditName.TabIndex = 78;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(12, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 30);
            this.label1.TabIndex = 77;
            this.label1.Text = "Product Name";
            // 
            // btnBoxCatEditcancel
            // 
            this.btnBoxCatEditcancel.AutoEllipsis = true;
            this.btnBoxCatEditcancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBoxCatEditcancel.FlatAppearance.BorderSize = 0;
            this.btnBoxCatEditcancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBoxCatEditcancel.Font = new System.Drawing.Font("Gill Sans MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBoxCatEditcancel.ForeColor = System.Drawing.Color.Maroon;
            this.btnBoxCatEditcancel.Location = new System.Drawing.Point(472, 308);
            this.btnBoxCatEditcancel.Name = "btnBoxCatEditcancel";
            this.btnBoxCatEditcancel.Size = new System.Drawing.Size(81, 38);
            this.btnBoxCatEditcancel.TabIndex = 85;
            this.btnBoxCatEditcancel.Text = "Cancel";
            this.btnBoxCatEditcancel.UseVisualStyleBackColor = false;
            this.btnBoxCatEditcancel.Click += new System.EventHandler(this.btnBoxCatEditcancel_Click);
            // 
            // btnBoxCatEditOk
            // 
            this.btnBoxCatEditOk.AutoEllipsis = true;
            this.btnBoxCatEditOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBoxCatEditOk.FlatAppearance.BorderSize = 0;
            this.btnBoxCatEditOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBoxCatEditOk.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBoxCatEditOk.ForeColor = System.Drawing.Color.Maroon;
            this.btnBoxCatEditOk.Location = new System.Drawing.Point(450, 240);
            this.btnBoxCatEditOk.Name = "btnBoxCatEditOk";
            this.btnBoxCatEditOk.Size = new System.Drawing.Size(103, 52);
            this.btnBoxCatEditOk.TabIndex = 84;
            this.btnBoxCatEditOk.Text = "OK";
            this.btnBoxCatEditOk.UseVisualStyleBackColor = false;
            this.btnBoxCatEditOk.Click += new System.EventHandler(this.btnBoxCatEditOk_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(12, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 30);
            this.label4.TabIndex = 86;
            this.label4.Text = "Product ID";
            // 
            // txtBoxCatEditID
            // 
            this.txtBoxCatEditID.BackColor = System.Drawing.Color.White;
            this.txtBoxCatEditID.Font = new System.Drawing.Font("Gill Sans MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCatEditID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txtBoxCatEditID.Location = new System.Drawing.Point(177, 100);
            this.txtBoxCatEditID.Name = "txtBoxCatEditID";
            this.txtBoxCatEditID.Size = new System.Drawing.Size(232, 30);
            this.txtBoxCatEditID.TabIndex = 87;
            this.txtBoxCatEditID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxCatEditID_KeyPress);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(178, 126);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(231, 4);
            this.panel2.TabIndex = 88;
            // 
            // roundButton2
            // 
            this.roundButton2.BackColor = System.Drawing.Color.White;
            this.roundButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton2.Location = new System.Drawing.Point(450, -92);
            this.roundButton2.Name = "roundButton2";
            this.roundButton2.Size = new System.Drawing.Size(266, 254);
            this.roundButton2.TabIndex = 76;
            this.roundButton2.UseVisualStyleBackColor = false;
            this.roundButton2.Click += new System.EventHandler(this.roundButton2_Click);
            // 
            // roundButton1
            // 
            this.roundButton1.BackColor = System.Drawing.Color.White;
            this.roundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton1.Location = new System.Drawing.Point(-174, -42);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.Size = new System.Drawing.Size(618, 462);
            this.roundButton1.TabIndex = 64;
            this.roundButton1.UseVisualStyleBackColor = false;
            // 
            // EditCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(565, 355);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtBoxCatEditID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnBoxCatEditcancel);
            this.Controls.Add(this.btnBoxCatEditOk);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.txtBoxCatEditDescription);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtBoxCatEditName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.roundButton2);
            this.Controls.Add(this.roundButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "EditCategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditCategory";
            this.Load += new System.EventHandler(this.EditCategory_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RoundButton roundButton1;
        private RoundButton roundButton2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RichTextBox txtBoxCatEditDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxCatEditName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBoxCatEditcancel;
        private System.Windows.Forms.Button btnBoxCatEditOk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoxCatEditID;
        private System.Windows.Forms.Panel panel2;
    }
}