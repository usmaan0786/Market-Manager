﻿namespace MarketManagmentSystem
{
    partial class DeleteCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roundButton1 = new MarketManagmentSystem.RoundButton();
            this.roundButton2 = new MarketManagmentSystem.RoundButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCatDeleteCancel = new System.Windows.Forms.Button();
            this.btnCatDeleteOk = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtBoxCatDeleteID = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // roundButton1
            // 
            this.roundButton1.BackColor = System.Drawing.Color.White;
            this.roundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton1.Location = new System.Drawing.Point(-174, -42);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.Size = new System.Drawing.Size(618, 462);
            this.roundButton1.TabIndex = 64;
            this.roundButton1.UseVisualStyleBackColor = false;
            // 
            // roundButton2
            // 
            this.roundButton2.BackColor = System.Drawing.Color.White;
            this.roundButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton2.Location = new System.Drawing.Point(450, -92);
            this.roundButton2.Name = "roundButton2";
            this.roundButton2.Size = new System.Drawing.Size(266, 254);
            this.roundButton2.TabIndex = 76;
            this.roundButton2.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Gill Sans MT", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(13, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 23);
            this.label3.TabIndex = 83;
            this.label3.Text = "Your Label";
            // 
            // btnCatDeleteCancel
            // 
            this.btnCatDeleteCancel.AutoEllipsis = true;
            this.btnCatDeleteCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCatDeleteCancel.FlatAppearance.BorderSize = 0;
            this.btnCatDeleteCancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCatDeleteCancel.Font = new System.Drawing.Font("Gill Sans MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatDeleteCancel.ForeColor = System.Drawing.Color.Maroon;
            this.btnCatDeleteCancel.Location = new System.Drawing.Point(472, 309);
            this.btnCatDeleteCancel.Name = "btnCatDeleteCancel";
            this.btnCatDeleteCancel.Size = new System.Drawing.Size(81, 38);
            this.btnCatDeleteCancel.TabIndex = 85;
            this.btnCatDeleteCancel.Text = "Cancel";
            this.btnCatDeleteCancel.UseVisualStyleBackColor = false;
            this.btnCatDeleteCancel.Click += new System.EventHandler(this.btnCatDeleteCancel_Click);
            // 
            // btnCatDeleteOk
            // 
            this.btnCatDeleteOk.AutoEllipsis = true;
            this.btnCatDeleteOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnCatDeleteOk.FlatAppearance.BorderSize = 0;
            this.btnCatDeleteOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCatDeleteOk.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCatDeleteOk.ForeColor = System.Drawing.Color.Maroon;
            this.btnCatDeleteOk.Location = new System.Drawing.Point(450, 241);
            this.btnCatDeleteOk.Name = "btnCatDeleteOk";
            this.btnCatDeleteOk.Size = new System.Drawing.Size(103, 52);
            this.btnCatDeleteOk.TabIndex = 84;
            this.btnCatDeleteOk.Text = "OK";
            this.btnCatDeleteOk.UseVisualStyleBackColor = false;
            this.btnCatDeleteOk.Click += new System.EventHandler(this.btnCatDeleteOk_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(178, 188);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(231, 4);
            this.panel2.TabIndex = 91;
            // 
            // txtBoxCatDeleteID
            // 
            this.txtBoxCatDeleteID.BackColor = System.Drawing.Color.White;
            this.txtBoxCatDeleteID.Font = new System.Drawing.Font("Gill Sans MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCatDeleteID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txtBoxCatDeleteID.Location = new System.Drawing.Point(177, 162);
            this.txtBoxCatDeleteID.Name = "txtBoxCatDeleteID";
            this.txtBoxCatDeleteID.Size = new System.Drawing.Size(232, 30);
            this.txtBoxCatDeleteID.TabIndex = 90;
            this.txtBoxCatDeleteID.TextChanged += new System.EventHandler(this.txtBoxCatDeleteID_TextChanged);
            this.txtBoxCatDeleteID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxCatDeleteID_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(12, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 30);
            this.label4.TabIndex = 89;
            this.label4.Text = "Product ID";
            // 
            // DeleteCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(565, 355);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.txtBoxCatDeleteID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnCatDeleteCancel);
            this.Controls.Add(this.btnCatDeleteOk);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.roundButton2);
            this.Controls.Add(this.roundButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DeleteCategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DeleteCategory";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RoundButton roundButton1;
        private RoundButton roundButton2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCatDeleteCancel;
        private System.Windows.Forms.Button btnCatDeleteOk;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtBoxCatDeleteID;
        private System.Windows.Forms.Label label4;
    }
}