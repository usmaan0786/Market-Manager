﻿namespace MarketManagmentSystem
{
    partial class DeleteSeller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roundButton1 = new MarketManagmentSystem.RoundButton();
            this.roundButton2 = new MarketManagmentSystem.RoundButton();
            this.btnBoxProductEditcancel = new System.Windows.Forms.Button();
            this.btnBoxProductEditOk = new System.Windows.Forms.Button();
            this.txtBoxSellerEditID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // roundButton1
            // 
            this.roundButton1.BackColor = System.Drawing.Color.White;
            this.roundButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton1.Location = new System.Drawing.Point(-174, -42);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.Size = new System.Drawing.Size(618, 462);
            this.roundButton1.TabIndex = 66;
            this.roundButton1.UseVisualStyleBackColor = false;
            this.roundButton1.Click += new System.EventHandler(this.roundButton1_Click);
            // 
            // roundButton2
            // 
            this.roundButton2.BackColor = System.Drawing.Color.White;
            this.roundButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.roundButton2.Location = new System.Drawing.Point(450, -92);
            this.roundButton2.Name = "roundButton2";
            this.roundButton2.Size = new System.Drawing.Size(266, 254);
            this.roundButton2.TabIndex = 78;
            this.roundButton2.UseVisualStyleBackColor = false;
            // 
            // btnBoxProductEditcancel
            // 
            this.btnBoxProductEditcancel.AutoEllipsis = true;
            this.btnBoxProductEditcancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBoxProductEditcancel.FlatAppearance.BorderSize = 0;
            this.btnBoxProductEditcancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBoxProductEditcancel.Font = new System.Drawing.Font("Gill Sans MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBoxProductEditcancel.ForeColor = System.Drawing.Color.DarkRed;
            this.btnBoxProductEditcancel.Location = new System.Drawing.Point(472, 308);
            this.btnBoxProductEditcancel.Name = "btnBoxProductEditcancel";
            this.btnBoxProductEditcancel.Size = new System.Drawing.Size(81, 38);
            this.btnBoxProductEditcancel.TabIndex = 108;
            this.btnBoxProductEditcancel.Text = "Cancel";
            this.btnBoxProductEditcancel.UseVisualStyleBackColor = false;
            this.btnBoxProductEditcancel.Click += new System.EventHandler(this.btnBoxProductEditcancel_Click);
            // 
            // btnBoxProductEditOk
            // 
            this.btnBoxProductEditOk.AutoEllipsis = true;
            this.btnBoxProductEditOk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnBoxProductEditOk.FlatAppearance.BorderSize = 0;
            this.btnBoxProductEditOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBoxProductEditOk.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBoxProductEditOk.ForeColor = System.Drawing.Color.Maroon;
            this.btnBoxProductEditOk.Location = new System.Drawing.Point(450, 240);
            this.btnBoxProductEditOk.Name = "btnBoxProductEditOk";
            this.btnBoxProductEditOk.Size = new System.Drawing.Size(103, 52);
            this.btnBoxProductEditOk.TabIndex = 107;
            this.btnBoxProductEditOk.Text = "OK";
            this.btnBoxProductEditOk.UseVisualStyleBackColor = false;
            this.btnBoxProductEditOk.Click += new System.EventHandler(this.btnBoxProductEditOk_Click);
            // 
            // txtBoxSellerEditID
            // 
            this.txtBoxSellerEditID.BackColor = System.Drawing.Color.White;
            this.txtBoxSellerEditID.Font = new System.Drawing.Font("Gill Sans MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxSellerEditID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.txtBoxSellerEditID.Location = new System.Drawing.Point(154, 157);
            this.txtBoxSellerEditID.Name = "txtBoxSellerEditID";
            this.txtBoxSellerEditID.Size = new System.Drawing.Size(212, 30);
            this.txtBoxSellerEditID.TabIndex = 124;
            this.txtBoxSellerEditID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtBoxSellerEditID_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Gill Sans MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(43, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 30);
            this.label6.TabIndex = 123;
            this.label6.Text = "Product";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Gill Sans MT", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(44, 269);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 23);
            this.label4.TabIndex = 122;
            this.label4.Text = "Your Label";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel11.Location = new System.Drawing.Point(155, 183);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(211, 4);
            this.panel11.TabIndex = 125;
            // 
            // DeleteSeller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(565, 355);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.txtBoxSellerEditID);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnBoxProductEditcancel);
            this.Controls.Add(this.btnBoxProductEditOk);
            this.Controls.Add(this.roundButton2);
            this.Controls.Add(this.roundButton1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DeleteSeller";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellerDelete";
            this.Load += new System.EventHandler(this.SellerDelete_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RoundButton roundButton1;
        private RoundButton roundButton2;
        private System.Windows.Forms.Button btnBoxProductEditcancel;
        private System.Windows.Forms.Button btnBoxProductEditOk;
        private System.Windows.Forms.TextBox txtBoxSellerEditID;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel11;
    }
}