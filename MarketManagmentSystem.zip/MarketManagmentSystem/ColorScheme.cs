﻿namespace MarketManagmentSystem
{
    internal class ColorScheme
    {
        private object blue400;
        private object blue5001;
        private object blue5002;
        private object lightBlue200;
        private object wHITE;

        public ColorScheme(object blue400, object blue5001, object blue5002, object lightBlue200, object wHITE)
        {
            this.blue400 = blue400;
            this.blue5001 = blue5001;
            this.blue5002 = blue5002;
            this.lightBlue200 = lightBlue200;
            this.wHITE = wHITE;
        }
    }
}